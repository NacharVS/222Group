﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace unit
{
    internal class Peasant : Unit
    {   
        public Peasant() : base("Peasant",45, 5, 0, 0)
        {
        }
    }
}
