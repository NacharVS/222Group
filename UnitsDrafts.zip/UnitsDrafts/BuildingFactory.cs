﻿namespace UnitsDrafts
{
    internal static class BuildingFactory
    {
        public static void CreateBarracs()
        {

        }
    }
}
